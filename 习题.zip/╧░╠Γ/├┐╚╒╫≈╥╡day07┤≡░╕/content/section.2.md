# Python基础语法--文件操作(关卡二)

##练习题1
匿名函数

1. 使用匿名函数为下面的列表排序
	* a = [{'name':'zhangsan','age':18},{'name':'lisi','age':19},{'name':'wanger','age':16}]
	* 按照姓名排序并打印
	* 按照年龄排序并打印



# 使用匿名函数为列表排序
a = [{"name":"zhangsan","age":18},{"name":"lisi","age":19},{"name":"wanger","age":16}]

# 按照name进行排序
a.sort(key = lambda x: x["name"])
print(a)

# 按照age进行排序
a.sort(key= lambda x: x["age"])
print(a)

## 练习题2
文件的打开,关闭及读写操作

**要求:**

1. 如何在打开的test.txt文件中写入数据?

答:运用函数write()完成向文件写入数据

2. 请在test.txt文件中写入"wow,so beautiful!".

答:f.write('wow,so beautiful!')

3. 怎么将test.txt文件中的数据读出来?

答:运用函数read()完成从文件读出数据
