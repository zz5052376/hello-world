# 函数2(关卡二)

### 练习题1

全局变量、局部变量

**要求：**，

1. 分别定义一个字符串类型的全局变量、列表类型的全局变量。定义函数test1，在函数中分别打印，总结有什么区别？

a = "hello python" 
b = [1,2,3,4,5]
def test1():
    # 使用全局变量
    print(a) # 不加global 可直接使用
    # a = "hello world"
    # 如果是这么写，并不是对全局变量修改，而是定义了一个局部变量，名字刚好与全局变量相同
    # 你既然没有用global大法，你(函数内的a)要用我(外部的a)的值请随便用，
    # 但你如果想改变，你变你的，休想带着我一起变
    print(b) 
    # 同理如果是
    # b = [2,3,4,5,6] 这么写
    # 并不是对全局变量修改，而是定义了一个局部变量，名字刚好与全局变量相同

2. 分别定义一个字符串类型的全局变量、列表类型的全局变量。定义函数test2，在函数中分别修改，总结有什么区别？

a = "hello python" 
b = [1,2,3,4,5]
def test2():
    # 使用全局变量
    print(a) 
    global a
    a = "hello world"
    # 如果这么使用global后，意即：
    # 管我什么类型，既然你(函数内的a)都用了global大法，那么我(外部的a)就跟定你了
    # 你(函数内的a)变什么样，我(外部的a)也要变成什么样
    
    print(b)
    global b
    b = [6,7,8,9,10]
    # 与a同理
    
    # 但是，但是，但是：
    # 因为b是可变类型，如果不加global的话，使用如b.append方法等去修改
    # 也会影响到全局变量里的b的值

3. 分别定义一个字符串类型的全局变量、列表类型的全局变量。定义函数test3，分别将全局变量作为参数传递给test3，并在test3中进行修改，总结有什么区别？

a = "hello python" 
b = [1,2,3,4,5]

def test3(a,b):    # 这里的a,b跟全局变量a，b没有一分钱关系，只是恰巧名字相同
    # 这里使用的形参的值，不是全局变量的值
    print(a)
    print(b)
test(a,b)   # 这里的a，b才是全局变量

**提示：**

1. 不可变类型全局变量，在函数内直接修改时，必须先用global声明，可变类型不需要

### 练习题2

可变类型、不可变类型、引用

**要求：**，

1. 如何理解引用传参，实际传递的是什么？

引用传参实际传递的是数据在内存中的地址，即传递参数是使用的变量作为实参，这是把数据的引用传递过去的

2. 分析下面的代码执行结束之后,打印什么内容

```python
def test1(a):
    a = 200
    print('test1--- %d'%a)

data = 100 # data 是一个数字
test1(data) 
print('main --- %d'%data)

```

结果
test1--- 200
main --- 100

3. 分析下面的代码执行结束之后,打印什么内容

```python
def test1(a):
    a.append(22)
    print('test1--- %s'%a)

data = [11] # data 是一个列表
test1(data)
print('main --- %s'%data)

```

结果
test1--- [11, 22]
main --- [11, 22]


4. 分析下面的代码执行结束之后,打印什么内容

```python
def test1(a):
    a = []
    a.append(22)
    print('test1--- %s'%a)

data = [11] # data 是一个列表
test1(data)
print('main --- %s'%data)

```

结果
test1--- [22]
main --- [11]

**提示：**

1. 变量存储的实际上数据的引用，可理解为数据在内存中的地址，传递参数时，传递的也是数据的引用


### 练习题3

函数的参数、函数的返回值

**要求：**

1. 分析下面三个函数的功能，比较三个函数的区别：

```python
def func1():
    i = 1
    sum = 0
    while i<=100:
        sum += i
        i += 1
    return sum

def func2(n):
    i = n
    sum = 0
    while i <=100:
        sum += i
        i += 1
    return sum

def func3(n=1, m=100):
    i = n
    sum = 0
    while i <= m:
        sum += i
        i += 1
    return sum
```

func1只能计算1到100的和，调用时不能传参数
func2可计算n到100的和，调用时必须传递一个参数
func可计算n到m的和，调用时可以不传，或传递1个或传递两个参数，默认计算1-100的和

2. 分别定义加减乘除四个函数，然后实现多个数之间的累加累减累除累乘操作，如[1,2,3,4,5]，累加即是1+2+3+4+5。注意当使用除法时，应判断被除数不能为0

# *args 传递过来的是个元组，如果没有数据，则是空元组--->()
# 如果使用if判断一个空元组会是被判断为失败
# 加法
def add(a,b,*args):
    ret = a+b
    if args:
        for i in args:
            ret = ret+i
    return ret
# 减法
def sub(a,b,*args):

    ret = a-b
    if args:    # 
        for i in args:
            ret = ret-i
    return ret
# 乘法
def mul(a,b,*args):
    ret = a*b
    if args:
        for i in args:
            ret = ret*i
    return ret
# 除法
def div(a,b,*args):
    # 如果b=0，就让结果为a
    if b == 0:
        ret = a
    else:
        ret = a/b
    if args:
        for i in args:
            if i == 0:
                # 如果i=0，就跳过
                continue
            ret = ret/i
    return ret

3. 使用不定长参数定义一个函数max_min，接受的参数类型是数值，最终返回这些数中的最大值和最小值

def max_min(*args):
    max = 0
    min = 0
    if len(args)==0:
        return 0,0
    elif len(args) == 1:
        return args[0],args[0]
    else:
        max = args[0]
        min = args[0]
        for i in args:
            if max < i:
                max = i
            if min > i:
                min = i
        return max,min

4. 定义一个函数接收参数 n，使用 while 循环计算n的阶乘并返回，调用函数并打印结果，如5阶乘"5!=120"的效果

ef each_mul(n):
    ret = 1
    for i in range(n):
         ret = ret*(i+1)
    print("%d!=%d"%(n,ret))

5. 定义一个函数，返回n(包含n)以内的奇数或者偶数组成的列表，默认返回全是奇数的列表

def get_oddoreven(n, type="odd"):
    ret = []
    if type=="odd":
        for i in range(1,n+1):
            if i%2!=0:
                ret.append(i)
    if type == "even":
        for i in range(1,n+1):
            if i%2==0:
                ret.append(i)
    return ret

6. 定义一个函数，打印出n以内的所有的素数(素数指除了1和本身以外不再有其他因数的值，比如5，7，11)
    * 遍历n以内的所有数字
    * 判断遍历的数字是否是素数

    def get_prime(n):
    ret = []
    if n<1:
        pass
    else:
        ret.append(2)
        for i in range(3,n):
            isPrime = True
            for j in range(2,i):
                if i%j==0:
                    isPrime = False
                    break
            if isPrime:
                ret.append(i)
    return ret

7. 定义一个函数，接受三个参数，分别为字符串s、数值a1、数值a2，将字符串s从下标a1开始的a2个字符删除，并把结果返回。a2默认值为0

def cut_str(s,a1,a2):
    length = len(s)
    if a1+1>length or a1>a2:
        return s
    else:
        s1 = s[:a1]
        s2 = s[a2+1:]
        return s1+s2

8. 请定义两个函数，一个函数画正方形，一个函数画三角形，并且可以从键盘输入值来决定画正方形还是画三角形以及决定是否退出程序

def square(n):
    for i in range(n):
        print("*"*n)
def triangle(n):
    for i in range(n):
        print("*"*(i+1))

9. 使用函数来封装名片管理系统各个功能，使用一个main函数来启动程序，并在main里控制循环

#用来存储所有的名片
info_cards = []

def print_menu():
    """打印功能提示"""
    print("="*50)
    print("    名片管理系统 V0.1")
    print(" 1:添加一个名片")
    print(" 2:删除一个名片")
    print(" 3:修改一个名片")
    print(" 4:查询一个名片")
    print(" 5:显示所有的名片")
    print(" 6:退出系统")
    print("="*50)

def add_card_info():
    """添加一个名片信息"""

    new_name = input("请输入你的名字:")
    new_tel = input("请输入你的手机号:")
    new_qq = input("请输入你的qq号:")
    new_addr = input("请输入你的住址:")

    #定义一个空字典,用来存储这个新人的信息
    new_infor = {}

    new_infor['name'] = new_name
    new_infor['tel'] = new_tel
    new_infor['qq'] = new_qq
    new_infor['addr'] = new_addr

    info_cards.append(new_infor)        

def print_all_card_info():
    """完成所有名片的打印"""
    for temp in info_cards:
        #此时temp是一个字典
        print("%s  %s  %s  %s"%(temp['name'], temp['qq'], temp['tel'], temp['addr']))


def find_card_info():
    """完成一个名片的查找"""
    find_name = input("请输入要查找的名字:")

    find_flag = 0#默认表示没找到

    for temp in info_cards:
        if temp['name'] == find_name:
            #找到了相同的名字
            print("%s  %s  %s  %s"%(temp['name'], temp['qq'], temp['tel'], temp['addr']))
            find_flag = 1
            break
    if find_flag == 0:
        print("没有找到.....")

def main():
    """完成整个程序的控制,主函数"""

    while True:
        #1. 打印功能提示
        print_menu()

        #2. 获取用户的选择
        num = int(input("请输入你的选择:"))

        #3. 根据用户的选择,执行相应的功能
        if num==1:
            add_card_info()
        elif num==2:
            pass
        elif num==3:
            pass
        elif num==4:
            find_card_info()
        elif num==5:
            print_all_card_info()
        elif num==6:
            pass
        else:
            print("输入有误,请重新输入....")
#让程序开始执行
main()

**提示：**

1. 注意当被除数为0时，程序会报错
2. 可以使用return结束一个函数的运行，这个函数中存在着的循环，也将被终止
3. 如果需要使用循环来控制整个程序，可以将每个功能块单独提取成函数，返回一定的值，在main函数中实现循环，整体控制各个函数的运行


### 练习题4

递归函数和匿名函数

**要求：**

1. 使用递归函数求n的阶乘

f calNum(num):
    if num >= 1:
        ret = num * calNum(num - 1)
    else:
        ret = 1
    return ret

**提示：**
1. 注意递归函数如果没有设计好退出条件，很可能造成死循环

