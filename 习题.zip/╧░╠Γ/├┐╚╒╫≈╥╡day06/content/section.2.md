# 函数2(关卡二)

### 练习题1

全局变量、局部变量

**要求：**，

1. 分别定义一个字符串类型的全局变量、列表类型的全局变量。定义函数test1，在函数中分别打印，总结有什么区别？

def test1():
    print(str)
    print(list)


str = "aaa"
list = [11, 22, 33]
test1()

2. 分别定义一个字符串类型的全局变量、列表类型的全局变量。定义函数test2，在函数中分别修改，总结有什么区别？

def test2():
    str = 111
    list = [2, 3, 4]
    print(str)
    print(list)


str = "aaa"
list = [11, 22, 33]
test2()

3. 分别定义一个字符串类型的全局变量、列表类型的全局变量。定义函数test3，分别将全局变量作为参数传递给test3，并在test3中进行修改，总结有什么区别？

def test3(str, list):
    str = 111
    list = [2, 3, 4]
    print(str)
    print(list)


str = "aaa"
list = [11, 22, 33]
test3(str, list)

**提示：**

1. 不可变类型全局变量，在函数内直接修改时，必须先用global声明，可变类型不需要

### 练习题2

可变类型、不可变类型、引用

**要求：**，

1. 如何理解引用传参，实际传递的是什么？

实际传递的是地址

2. 分析下面的代码执行结束之后,打印什么内容

```python
def test1(a):
    a = 200
    print('test1--- %d'%a)

data = 100 # data 是一个数字
test1(data)
print('main --- %d'%data)

```
test1---200
main --- 100

3. 分析下面的代码执行结束之后,打印什么内容

```python
def test1(a):
    a.append(22)
    print('test1--- %s'%a)

data = [11] # data 是一个列表
test1(data)
print('main --- %s'%data)

```

test1---[11,22]
main ---[11,22]

4. 分析下面的代码执行结束之后,打印什么内容

```python
def test1(a):
    a = []
    a.append(22)
    print('test1--- %s'%a)

data = [11] # data 是一个列表
test1(data)
print('main --- %s'%data)

```

test1---[22]
main ---[11]

**提示：**

1. 变量存储的实际上数据的引用，可理解为数据在内存中的地址，传递参数时，传递的也是数据的引用


### 练习题3

函数的参数、函数的返回值

**要求：**

1. 分析下面三个函数的功能，比较三个函数的区别：

```python
def func1():                   求1-100的和
    i = 1
    sum = 0
    while i<=100:
        sum += i
        i += 1
    return sum

def func2(n):                  求1-n的和
    i = n
    sum = 0
    while i <=100:
        sum += i
        i += 1
    return sum

def func3(n=1, m=100):          求n-m的和，n和m的值默认为1和100
    i = n
    sum = 0
    while i <= m:
        sum += i
        i += 1
    return sum
```

2. 分别定义加减乘除四个函数，然后实现多个数之间的累加累减累除累乘操作，如[1,2,3,4,5]，累加即是1+2+3+4+5。注意当使用除法时，应判断被除数不能为0

def jia(*a):
    res = 0
    for x in a:
        res += x
    return res


def jain(a, *b):
    res = a
    for x in b:
        res -= b
    return res


def chen(*a):
    res=1
    for x in a:
        res *= a
    return res


def chu(a, *b):
    res = a
    for x in b:
        if x != 0:
            res /= x
            return res
        else:
            print("除数不能为0")

3. 使用不定长参数定义一个函数max_min，接受的参数类型是数值，最终返回这些数中的最大值和最小值

def max_min(*a):
    ma = a[0]
    mi = a[0]
    for x in a:
        if x > ma:
            ma = x
        else:
            mi = x
    return ma, mi


c=max_min(1, 2, 3, 4, 5, 6, 7, 8)
print(c)

4. 定义一个函数接收参数 n，使用 while 循环计算n的阶乘并返回，调用函数并打印结果，如5阶乘"5!=120"的效果

def fun(n):
    i = 1
    res = 1
    while i <= n:
        res *= i
        i += 1
    return res

n = 5
a = fun(n)
print("%d!=%d" % (n, a))

5. 定义一个函数，返回n(包含n)以内的奇数或者偶数组成的列表，默认返回全是奇数的列表

def fun(n, odd=True):
    res = []
    i = 1
    while i <= n:
        if i % 2 == 1 and odd is True:
            res.append(i)
        elif i % 2 ==0 and odd is False:
            res.append(i)
        i += 1
    return res


a = fun(30, False)
print(a)

6. 定义一个函数，打印出n以内的所有的素数(素数指除了1和本身以外不再有其他因数的值，比如5，7，11)
    * 遍历n以内的所有数字
    * 判断遍历的数字是否是素数
def fun(n):
    list = []
    i = 1
    while i <= n:
        j = 2
        while j < i:
            if i%j == 0:
                break
            j += 1
        else:
            list.append(i)
        i += 1
    del list[0]
    return list


a = fun(20)
print(a)

7. 定义一个函数，接受三个参数，分别为字符串s、数值a1、数值a2，将字符串s从下标a1开始的a2个字符删除，并把结果返回。a2默认值为0

def fun(s, a1, a2=0):
    str = s[:a1] + s[a1+a2+1:]
    return str


c = fun("abcdef", 1, 2)
print(c)

8. 请定义两个函数，一个函数画正方形，一个函数画三角形，并且可以从键盘输入值来决定画正方形还是画三角形以及决定是否退出程序

def tria():
    """画三角形"""
    n = int(input("请输入三角形高度n"))
    i = 1
    while i <= n:
        j = 1
        while j < i+1:
            print("* ", end="")
            j += 1
        print()
        i += 1
    i = 4


def squ():
    """画正方形"""
    n = int(input("请输入正方形高度n"))
    i = 1
    while i <= n:
        print("*  "*n)
        i += 1


while True:
    print("="*20)
    print("1.画三角形")
    print("2.画正方形")
    print("0.退出")
    print("=" * 20)
    command = input("请输入指令")
    if command == "1":
        tria()
    elif command == "2":
        squ()
    elif command == "0":
        break
    else:
        print("指令错误")

9. 使用函数来封装名片管理系统各个功能，使用一个main函数来启动程序，并在main里控制循环

**提示：**

1. 注意当被除数为0时，程序会报错
2. 可以使用return结束一个函数的运行，这个函数中存在着的循环，也将被终止
3. 如果需要使用循环来控制整个程序，可以将每个功能块单独提取成函数，返回一定的值，在main函数中实现循环，整体控制各个函数的运行
