# 字符串、列表、元组、字典（关卡二）

### 练习题1

字符串的基本应用

**要求：**

1. 完成字符串的长度统计以及逆序打印
    * 设计一个程序，要求只能输入长度低于31的字符串，否则提示用户重新输入
    * 打印出字符串长度
    * 使用切片逆序打印出字符串
	
while True:
    str=input("请输入一串长度低于31的字符串：")
    if len(str)<31:
        print("字符串长度为%d"%len(str))
        print(str[::-1])
        break
    else:
        print("字符串长度过长，请重新输入")
print("程序结束")

2. 用户名和密码格式校验程序
    * 要求从键盘输入用户名和密码
    * 校验格式是否符合规则，用户名长度6-20，并且用户名必须以字母开头
    * 如果不符合，打印出不符合的原因，并再次提示输入
	
while True:
    name=input("请输入姓名(长度6-20)：")
    tel=input("请输入电话(长度11)：")
    sex=input("请输入性别(男或女)：")
    if (len(name)<6
        or len(name)>20
        or len(tel)!=11
        or (sex!="男" and sex!="女")):
        print("输入的信息有误")
    else:
        print("姓名为%s"%name)
        print("电话为%s"%tel)
        print("性别为%s"%sex)
        break

3. 名片管理器v1.0 升级版，记录一张名片
    * 使用个三个变量来记录用户输入的信息，包含姓名、电话、性别
    * 姓名长度不是在6-20范围内，则提示错误
    * 电话号码长度不是11，则提示错误
    * 性别不是男或女，则提示错误
    * 所有信息校验通过后，打印名片信息，程序结束
	
while True:
    name=input("请输入姓名(长度6-20)：")
    if len(name)<6 or len(name)>20:
        print("名字过长")
    else:
        break
while True:
    tel=input("请输入电话(长度11)：")
    if len(tel)!=11:
        print("电话号码长度错误")
    else:
        break
while True:
    sex=input("请输入性别(男或女)：")
    if sex!="男" and sex!="女":
        print("性别错误")
    else:
        break
        
print("姓名为%s"%name)
print("电话为%s"%tel)
print("性别为%s"%sex)

**提示：**
 
 1. 题1：
    * 可以使用len(字符串)查看字符串的长度
    * 字符串[::-1]可以实现字符串逆序

 2. 题2：
    * len(字符串)获取字符串长度
    * if 字符串[0] in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" 可以判断第一个是不是字母
    * 使用死循环控制程序不退出
    * 设计当输入如"QUIT"时，退出程序

3. 题3：
    * 使用 3 个变量存储好友的 3 个信息
    * 使用 3 个死循环分别处理姓名、电话、性别的输入

### 练习题2

列表和字典的基本应用

**要求：**

 1. 从键盘中输入5个学生的名字，存储到列表中，然后打印出每个学生名字中的第2个字母
 
name_list=[]
i=0
while i<5:
    name=input("请输入一个学生的姓名：")
    name_list.append(name)
    i+=1
for name in name_list:
    print(name[1])
 
 2. 从键盘获取5个学生的名字，然后随机抽出一名学生去打扫卫生
 
import random
name_list=[]
i=0
while i<5:
    name=input("请输入一个学生的姓名：")
    name_list.append(name)
    i+=1
x=random.randint(0,4)
print("%s同学去打扫卫生"%name_list[x])
 
 3. 名片管理器v2.0，管理多张名片，可以不断添加和查看名片
    * 在上一版本的基础上，修改为使用[列表]来存储多张名片信息(注意阅读本题的提示信息)
    * 可以打印名片内容的功能
    * 可以清空名片内容的功能
	
card_list=[]
while True:
    print("="*20)
    print("1.添加名片")
    print("2.打印名片")
    print("3.清空名片")
    print("0.退出")
    print("=" * 20)
    command=input("请输入指令(0-3)：")
    if command=="1":
        while True:
            name=input("请输入姓名(长度6-20)：")
            if len(name)<6 or len(name)>20:
                print("名字过长")
            else:
                break
        while True:
            tel=input("请输入电话(长度11)：")
            if len(tel)!=11:
                print("电话号码长度错误")
            else:
                break
        while True:
            sex=input("请输入性别(男或女)：")
            if sex!="男" and sex!="女":
                print("性别错误")
            else:
                break
        card_list.append(name)
        card_list.append(tel)
        card_list.append(sex)
        input("输入成功，请按任意键继续")
    elif command=="2":
        print(card_list)
        input("打印成功，请按任意键继续")
    elif command=="3":
        while len(card_list)!=0:
            card_list.pop()
        input("清空成功，请按任意键继续")
    elif command=="0":
        break
    else:
        input("输入有误，请重新输入,按任意键继续")
    
**提示：**
 
 1. 题1：
    * 使用for循环挨个取出列表里的字符串，然后使用下标[1]取出第二个字母
 2. 题2：
    * 将学生的名字存储到列表里，然后使用随机数来生成下标，使用随机下标获取姓名并打印
 2. 题3：
    * 保存名片，需要按顺序将输入的信息保存到列表里，比如 [姓名,电话,性别]
    * 打印全部名片，就是使用下标获取列表里的每个信息，然后打印
    * 清空内容，就是将列表的所有数据都移除掉，在循环里使用 pop 来删除列表最后一个数据, 当列表长度为 0 则说明已经删完

### 练习题3

字典的基本应用

**要求：**

 1. 把关卡2-练习1中的题1增加一个功能，要求统计输入的字符串中不同字符的个数，使用字典存储，并打印出来
 
dic={}
while True:
    str=input("请输入一串长度低于31的字符串：")
    if len(str)<31:
        print("字符串长度为%d"%len(str))
        print(str[::-1])
        break
    else:
        print("字符串长度过长，请重新输入")
for let in str:
    dic[let]=0
for let in str:
    if let in dic:
        dic[let]+=1
print(dic)
print("不同字符个数为%d个"%len(dic))
 
 2. 字符翻译程序
    * 查看笔记本键盘1-9还有0号键其上方的字符，要求用户输入"1"，那么输出"!",输入"2"，那么输出"@",以此类推
    * 用字典完成这个任务
    * 用户如果输入的字符长度超过1或者是除数字以外其他字符，提示"未收录该字符的含义，请重新输入"
 
dic={"1":"!","2":"@","3":"#","4":"$","5":"%"
    ,"6":"^","7":"&","8":"*","9":"(","0":")"}
while True:
    char=input("请输入一个键盘字符（0-9,按Q键退出）：")
    if char in dic:
        print(dic[char])
    elif char=="Q":
        break
    else:
        input("未收录该字符的含义，请重新输入，按回车键继续")
 
 3. 职员信息管理系统
    * 使用列表来记录多个员工的信息
    * 要求依次从键盘录入每位员工的信息，并使用字典来保存，包括姓名、员工id、出生年月、籍贯、身份证号、入职时间
    * 要求能随时查看已录入的员工信息
	
staff_list=[]
while True:
    person = {}
    print("="*20)
    print("1.输入员工信息")
    print("2.查看员工信息")
    print("0.退出")
    print("="*20)
    command=input("请输入指令：")
    if command=="1":
        # 括姓名、员工id、出生年月、籍贯、身份证号、入职时间
        name=input("请输入姓名：")
        staff_id = input("请输入员工id：")
        birth = input("请输入出生年月：")
        native = input("请输入籍贯：")
        id_card = input("请输入身份证号：")
        st_wk_tm = input("请输入入职时间")
        person["name"]=name
        person["staff_id"]=staff_id
        person["birth"]=birth
        person["native"]=native
        person["id_card"]=id_card
        person["st_wk_tm"]=st_wk_tm
        staff_list.append(person)
    elif command=="2":
        print(staff_list)
    elif command=="0":
        break
    else:
        input("指令输入错误，请按回车键重新输入")

print("退出系统")


**提示：**
 
 1. 题1：
    * 使用字典来存储，键为出现过的字符，值为字符出现的次数，比如 {'a':2,'c':1}
    * 使用for循环遍历每个字符，循环里使用  if 字符 in dict 判断字典是否已经存在该字符的键，存在则把对应键的数字+1
 
 2. 题2：
    * 使用字典先设计好{"1":"!","2":@ ......}来存储
    * 然后通过用户输入的字符来获取                                                
 
 3. 题3：
    * 每位职员的信息可以用字典保存，然后添加到一个职员列表中进行管理，要查看时，遍历这个职员列表即可