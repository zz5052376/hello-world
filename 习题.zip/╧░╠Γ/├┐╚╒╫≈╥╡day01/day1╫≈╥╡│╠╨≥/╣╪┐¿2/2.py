name="helloworldhaha"
print(name.isalpha())