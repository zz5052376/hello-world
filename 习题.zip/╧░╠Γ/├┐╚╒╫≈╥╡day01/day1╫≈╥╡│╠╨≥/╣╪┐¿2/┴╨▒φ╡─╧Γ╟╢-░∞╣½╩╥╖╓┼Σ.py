import random
offices=[[],[],[]]
names=['a','b','c','d','e','f','g','h']
for name in names:
    index=random.randint(0,2)
    offices[index].append(name)
i=1
for temp in offices:
    print("办公室%d的人数为%d人"%(i,len(temp)))
    i+=1
    for name in temp:
        print(name,end=" ")
    print("")
    print("-"*20)