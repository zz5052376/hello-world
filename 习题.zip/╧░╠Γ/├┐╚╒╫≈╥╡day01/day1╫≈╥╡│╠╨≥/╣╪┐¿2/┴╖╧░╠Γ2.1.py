a="aStr"
b=a[3:0:-1]+a[0]
print(b)