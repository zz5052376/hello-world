print("hello world!"*2)
#这是我们的第一个程序