# Python基础语法--文件操作(关卡二)

##练习题1
匿名函数

1. 使用匿名函数为下面的列表排序
	* a = [{'name':'zhangsan','age':18},{'name':'lisi','age':19},{'name':'wanger','age':16}]
	* 按照姓名排序并打印
	* 按照年龄排序并打印

a = [{"name": "zhangsan", "age": 18},{"name": "lisi", "age": 19},
     {"name": "wangwu", "age": 16}]
a.sort(key=lambda x: x["name"],reverse=True)
print(a)
a.sort(key=lambda x: x["age"],reverse=True)
print(a)
	
## 练习题2

文件的打开,关闭及读写操作

**要求:**

1. 如何在打开的test.txt文件中写入数据?

f = open("test.txt", "a")
f.write("\n66666666666")
f.close()

2. 请在test.txt文件中写入"wow,so beautiful!".

f = open("test.txt", "a")
f.write("wow,so beautiful!")
f.close()

3. 怎么将test.txt文件中的数据读出来?

f = open("test.txt","r")
content = f.read()
f.close()
print(content)
