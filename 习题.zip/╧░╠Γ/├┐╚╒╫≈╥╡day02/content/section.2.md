# python基础语法(if)（关卡一）

理解判断语句并熟练应用

### 练习题1

强化练习判断语句

**要求:**

1. 列举你所想到的开发中使用判断语句的场景。

答：需要通过用户的输入执行不同的操作时。

2. 1-7七个数字，分别代表周一到周日。新建文件，编写代码，如果输入的数字是6或7，输出“周末”。

	day=int(input("请输入1-7中的一个数字："))
	if day==6 or day==7:
		print("周末")

3. 1-7七个数字，分别代表周一到周日。新建文件，编写代码，如果输入的数字是6或7，输出“周末”，否则输出“工作日”。

	day=int(input("请输入1-7中的一个数字："))
	if day==6 or day==7:
		print("周末")
	else:
		print("工作日")

4. 1-7七个数字，分别代表周一到周日。新建文件，编写代码，如果输入的数字是6或7，输出“周末”，如果输入的数字是1-
5，输出“工作日”，如输入其他数字，输出“错误”。

	day=int(input("请输入1-7中的一个整数："))
	if day==6 or day==7:
		print("周末")
	elif day==1 or day==2 or day==3 or day==4 or day==5:
		print("工作日")
	else:
		print("错误")

5. 根据以上题目，简述 if 和 if-else 以及 if-elif-else 的使用格式和区别。

答：if中if的条件如果不满足，离开判断，执行后续代码，if-else中如果if的条件不满足，执行else内的代码，if-elif-else
中如果if条件不满足，继续判断elif的条件是否满足，如果都不满足，则执行else中的代码。

**提示:**

1. 第2、3、4题，分别使用if、if-else、if-elif-else来完成

### 练习2

判断语句增强练习

**要求:**

1. 使用 if 语句完成剪刀石头布程序
	* 让用户输入出拳的数字(剪刀[0] 石头[1] 布[2])
	* 电脑生成出拳的数字
	* 判断输赢，打印结果
	
	import random
	player=int(input("请输入[剪刀,0][石头，1][布，2]"))
	computer=random.randint(0,2)
	print("电脑出拳为 %d"%computer)
	if ((player==0 and computer==2) or (player==1 and computer==0)
		or (player==2 and computer==1)):
		print("你赢了")
	elif player==computer:
		print("平局")
	else:
		print("你输了")

2. 输入一个人的身高\(m\)和体重\(kg\)，根据BMI公式（体重除以身高的平方）计算他的BMI指数。

 * 例如：一個52公斤的人，身高是155cm，则BMI为 :

  `52(kg)/1.55^2(m)= 21.6`

 *  BMI指数：
  ```
  低于18.5：过轻
  18.5-25：正常
  25-28：过重
  28-32：肥胖
  高于32：严重肥胖
  ```
  
    high=float(input("请输入你的身高（米）："))
	heavy=float(input("请输入你的体重（千克）："))
	BMI=heavy/high**2
	if BMI>32:
		print("你的BMI指数为 %d ,严重肥胖"%BMI)
	elif BMI>28:
		print("你的BMI指数为 %d ,肥胖" % BMI)
	elif BMI>25:
		print("你的BMI指数为 %d ,过重" % BMI)
	elif BMI>18.5:
		print("你的BMI指数为 %d ,正常" % BMI)
	else:
		print("你的BMI指数为 %d ,过轻" % BMI)

3. 编写代码设计简易计算器，可以进行基本的加减乘除运算。
	* 用户输入第一个数字
	* 用户输入一个操作符 +、-、\*、/
	* 用户输入第二个数字
	* 判断运算类型，并进行计算
	
	a=float(input("请输入第一个数字："))
	fu=input("请输入运算符号（+、-、*、/）：")
	b=float(input("请输入第二个数字："))
	if fu=="+":
		print("答案为 %.2f，保留两位小数"%(a + b))
	elif fu=="-":
		print("答案为 %.2f，保留两位小数" % (a - b))
	elif fu=="*":
		print("答案为 %.2f，保留两位小数" % (a * b))
	elif fu=="/":
		if b==0:
			print("除数不能为0")
		else:
			print("答案为 %.2f，保留两位小数" % (a / b))
	else:
		print("运算符号输入错误")


**提示:**

1. 第1题中，电脑出拳，在开始时应该是一个固定的值，当 if 判断的逻辑没问题之后，再使用随机的值
2. 第3题中，不要忘记使用int()进行类型转换
3. 第3题中，依次输入第一个数、运算符、第二个数，使用if去判断是什么运算
4. 用input输入加号(+)时，注意是字符串的"+"，所以在用if判断的时候，也需要 if xxx=="+"
5. 注意被除数不能为 0
