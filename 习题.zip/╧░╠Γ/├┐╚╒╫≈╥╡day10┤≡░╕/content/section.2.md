# Python基础语法--面向对象2(关卡二)

## 练习题1

面向对象的理解

**要求：**

1. 定义一个类，提供可以重新设置私有属性name的方法，限制条件为字符串长度小于10,才可以修改.

    ```python
    class Person(object):
        def __init__(self, name):
            self.name = name

        def set_name(self, name):
            if len(name) < 10:
                self.name = name
    ```

2. 在一个对象销毁的时候，可以在什么函数释放资源?
    * 魔法方法 `__del__`

3. __del__()方法是手动调用还是解释器自动调用?
    * 解释器自动调用

4. 创建一个动物类,并通过__init__方法接受参数(name),使用私有属性name保存参数值，并打印"init被调用".

    ```python
    class Animal(object):
        def __init__(self, name):
            self.__name = name
            print('init 被调用')
    ```

5. 在动物类中定义一个__del__()方法,使其在删除的时候自动被调用,并打印"del被调用".

    ```python
    class Animal(object):
        def __init__(self, name):
            self.__name = name
            print('init 被调用')

        def __del__(self):
            print('del 被调用')
    ```

6. 使用动物类，实例化一个dog对象取名"八公"

    ```python
    dog = Animal('八公')
    ```

7. 将实例dog赋值给变量dog1和dog2.

    ```python
    dog1 = dog
    dog2 = dog
    ```

8. 分别删除变量名dog,dog1和dog2,并在删除之前分别打印：删除对象dog, dog1和dog2.

    ```python
    print('删除对象 dog')
    del dog
    
    print('删除对象 dog1')
    del dog1
    
    print('删除对象 dog2')
    del dog2
    ```

9. 观察运行结果发现什么问题?
    * 当对象的最后一个引用 dog2 被删除后，对象才会执行__del__方法
    * 当对象的所有引用都被删除后，对象才会被销毁

**提示: **
1. 当对象的所有引用都被删除后，对象才会被销毁

## 练习题2

封装 继承 多态

**要求:**

1. 简单描述什么是多继承
    * 一个子类同时继承多个父类

2. 写出一个简单的多继承案例.
    
    ```python
    class Ma(object):
        pass
    
    class Lv(object):
        pass

    class LuoZi(Ma, Lv):
        pass
    ```

3. 如果多个父类中有相同的方法,那么子类在调用的时候,调用哪个?怎样保证调用指定父类的方法？
    * 默认是根据 mro 算法来判断父类方法的查找顺序
    * 如果要指定父类，可以使用代码：父类名.方法名(子类对象, 参数列表)

4. 简单描述什么是重写
    * 子类和父类有同名的方法，则子类对象调用是自己的方法

5. 下面有一个类,请创建一个子类并重写类中的方法
    ```python
    #coding=utf-8
    class Car(self):
        def run(self):
            print("奔驰在路上!")
    ```

    答案:
	```python
    class BMW(Car):
        def run(self):
            print('在田野里飞驰啦~')
	```

6. 你是如何理解多态的?
    * 父类变量可以引用子类对象
    * 当子类重写了父类的方法，则子类对象会调用子类方法

7. 请解读出多态一章中python"鸭子类型"程序的运行结果.
    
    ```python
    class F1(object):
        def show(self):
            print 'F1.show' 

    class S1(F1):

        def show(self):
            print 'S1.show' 

    class S2(F1):

        def show(self):
            print 'S2.show' 

    def Func(obj):
        obj.show()

    s1_obj = S1()
    Func(s1_obj) 

    s2_obj = S2()
    Func(s2_obj)
    ```
    * 打印结果为
        > S1.show
        > 
        > S2.show
    * 可以看到 Func 函数可以任意接收 F1 类或它的子类，并且不同子类有不同的执行效果
    * 只要传递给 Func 函数的参数是 F1 类或它的子类，就可以保证程序能够稳定运行

**提示: **
1. 多态：父类变量能够引用子类对象，当子类有重写父类方法，调用的将是子类方法。


### 练习题3

利用继承编写下面一段代码

**要求：**

1. 动物:吃,喝,跑,玩

2. 猫:喵喵叫

3. 狗:旺旺叫

4. 猫、狗继承于动物,并且有2、3中自己的方法.

5. 创建猫和狗的对象，并调用可用的所有方法

    ```python
    class Animal(object):
        # 动物:吃,喝,跑,玩

        def eat(self):
            print('吃')

        def drink(self):
            print('喝')

        def run(self):
            print('跑')

        def play(self):
            print('玩')

    class Cat(Animal):
        # 猫:喵喵叫,继承于动物

        def talk(self):
            print('喵')

    class Dog(Animal):
        # 狗:旺旺叫,继承于动物

        def talk(self):
            print('汪')

    cat = Cat()
    cat.eat()
    cat.drink()
    cat.run()
    cat.play()
    cat.talk()

    dog = Dog()
    dog.eat()
    dog.drink()
    dog.run()
    dog.play()
    dog.talk()
    ```