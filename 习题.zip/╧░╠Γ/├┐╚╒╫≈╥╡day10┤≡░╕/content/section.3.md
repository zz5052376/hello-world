# Python基础语法--面向对象2(关卡三)

## 练习题1

编写一段代码以完成下面的要求

**要求：**

1. 定义一个人的基类,类中要有初始化方法,方法中初始化人的姓名,年龄.

    ```python
    class Person(object):
        def __init__(self, name, age):
            self.name = name
            self.age = age
    ```

2. 提供__str__方法，返回姓名和年龄信息

    ```python
    def __str__(self):
        return '%s 的年龄是 %d' % (self.name, self.age)
    ```

2. 将类中的姓名和年龄私有化.

    ```python
    def __init__(self, name, age):
        self.__name = name
        self.__age = age
    ```

3. 提供获取私有属性的方法.

    ```python
    def get_name(self):
        return self.__name

    def get_age(self):
        return self.__age
    ```

4. 提供可以设置私有属性的方法.

    ```python
    def set_name(self, new_name):
        self.__name = new_name

    def set_age(self, new_age):
        self.__age = new_age
    ```

5. 设置年龄时限制范围(0-100).
    
    ```python
    def set_age(self, new_age):
        if new_age > 0 and new_age <= 100:
            self.__age = new_age
        else:
            print('年龄设置失败，必须要在 0-100 之内')
    ```

**提示：**

1. 将公有属性变为私有属性的方法是在其前面加上__即可.

	
## 练习题2

编写一段代码以练习继承和多态

**要求：**

1. 创建一个动物的基类,其中有一个run方法

    ```python
    class Animal(object):
        def run(self):
            print('跑起来')
    ```

2. 创建一个Cat类继承于动物类

    ```python
    class Cat(Animal):
        pass
    ```

3. 创建一个Dog类继承于动物类

    ```python
    class Dog(Animal):
        pass
    ```

4. Cat类中不仅有run方法还有eat方法

    ```python
    class Cat(Animal):
        def run(self):
            print('猫在跑')

        def eat(self):
            print('猫在吃')
    ```

5. Dog类中方法同上

    ```python
    class Dog(Animal):
        def run(self):
            print('狗在跑')
            
        def eat(self):
            print('狗在吃')
    ```

6. 创建一个letRun函数，可以接收动物及其子类对象，并调用run方法

    ```python
    def letRun(animal):
        animal.run()
    ```

6. 编写测试代码以验证功能正常

    ```python
    # 动物测试
    animal = Animal()
    letRun(animal)

    # 猫测试
    cat = Cat()
    letRun(cat)
    cat.eat()

    # 狗测试
    dog = Dog()
    letRun(dog)
    dog.eat()
    ```

## 练习题3

标出下列代码中哪些是is-a的关系，哪些是has-a的关系。有##的地方是需要标注的地方.

**要求：**
```Python
class Animal(object):  
    pass  
  
## 1 --- is-a
class Dog(Animal):  
  
    def __init__(self, name):  
        ## 2
        self.name = name  
  
## 3 --- is-a
class Cat(Animal):  
  
    def __init__(self, name):  
        ## 4  
        self.name = name  
  
## 5 --- is-a  
class Person(object):  
  
    def __init__(self, name):  
        ## 6 --- has-a  
        self.name = name   
        self.pet = None  
  
## 7 --- is-a
class Employee(Person):  
  
    def __init__(self, name, salary):  
        
        super(Employee, self).__init__(name)  
        ## 8 --- has-a
        self.salary = salary  
  
## 9 --- is-a
class Fish(object):  
    pass  
  
## 10 --- is-a
class Salmon(Fish):  
    pass  
  
## 11 --- is-a 
class Halibut(Fish):  
    pass  
  
  
## 12 --- is-a
rover = Dog("Rover")  
  
## 13 --- is-a 
satan = Cat("Satan")  
  
## 14 --- is-a 
mary = Person("Mary")  
```

**提示：**

1. is-a就是对象和类之间通过类的关系相关联
2. has-a是对象和类相关联是因为他们彼此引用
