# Python基础语法--文件操作(关卡三)

## 练习题1

编写一段代码以完成两份文件之间的相互备份

**要求：**

1. 在python用户目录下创建python06基础班文件夹

2. 在文件夹中创建gailun.txt文件

3. 打开文件在gailun.txt中写入"德玛西亚！人在塔在！"，并关闭文件

4. 读取文件内容，将输入的数据输出到终端上，并关闭文件

5. 在文件夹中创建gailun副本.txt文件

6. 读取gailun.txt文件中的数据，写入gailun副本.txt文件中，并关闭两个文件

7. 打开副本文件，查看文件中是否有内容

      1 #coding=utf-8
	  2
	  3 #1.打开gailun.txt文件
	  4 f = open('gailun.txt','r+')
	  5
	  6 #2.在文件中写入“德玛西亚！人在塔在！”
	  7 f.write("德玛西亚！人在塔在！")
	  8
	  9 #3.输出
	 10 content = f.readlines()
	 11 #print(content)
	 12
	 13 #4.打开gailun副本.txt文件
	 14 f1 = open('gailun01.txt', 'w+')
	 15
	 16 #5.写入gailun.txt中的数据
	 17 for temp in content:
	 18     f1.write(temp)
	 19
	 20 #6.关闭两个文件
	 21
	 22 f.close()
	 23 f1.close()

**提示：**

1. 文件的操作流程打开文件，写入/读取数据，关闭文件


## 练习题2

编写一段代码以完成文件的定位读取

**要求：**

1. 在python用户目录下创建python06基础班文件夹

2. 在此文件夹中建立read.txt文件。

3. 在此文件中写入"hello world! hello python!hello everyone!"

4. 打开文件，读取5个字符。

5. 查找当前位置，并格式化输出为 "当前读写位置是 xxx"。

6. 把指针重新定位到文件的开头，读取10个字符串。

7. 关闭文件

	  2 #coding=utf-8
	  3
	  4 f = open("./read.txt", "r+")
	  5
	  6 str = f.read(5)
	  7
	  8 print ("读取的字符串是:%s"%str)
	  9
	 10 #查找当前位置
	 11 ps = f.tell()
	 12 print ("当前位置:%s"%ps)
	 13
	 14 #把指针重新定位到文件开头
	 15 position = f.seek(0,0)
	 16
	 17 str = f.read(10)
	 18
	 19 print ("重新读取字符串:%s"%str)
	 20
	 21 #关闭文件
	 22 f.close()

## 练习题3

编写一个py文件完成以下要求

**要求：**

1. 制作一个名片，键盘输入姓名，年龄，性别，班级编号。

2. 将名片信息格式化输出到文件card.txt中。
	* 格式为: name:xxx,age:xxx,sex:xxx,class_num:xxx

3. 打开card.txt文件，读取文件中名片的内容。

4. 获取当前文件读写位置，并打印出来。

5. 关闭文件

	  2 #coding=utf-8
	  3 import sys
	  4
	  5 f=open('card.txt','w')
	  6 clsname=input('请输入班级:')
	  7 name=input('请输入姓名:')
	  8 age=input('请输入年龄:')
	  9 gender=input('请输入性别:')
	 10
	 11 old=sys.stdout #将当前系统输出储存到一个临时变量中
	 12 sys.stdout=f  #输出重定向到文件
	 13 #print ('Hello weird') #测试一个打印输出
	 14
	 15 print('班级:%s，姓名:%s，年龄:%s，性别:%s'%(clsname,name,age,    gender))
	 16 sys.stdout=old #还原原系统输出
	 17 #查找当前位置
	 18 ps = f.tell()
	 19 print ("当前位置:%s"%ps)
	 20 f.close()


**提示：**
1. 代码中文件重定向代码段用一下代码
```
	old=sys.stdout #将当前系统输出储存到一个临时变量中
	sys.stdout=f  #输出重定向到文件
	print("你要重定向的内容")
	sys.stdout=old #还原原系统输出
```
