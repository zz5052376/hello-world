# Python基础语法--文件操作
## 练习题1
文件的基本操作:复制、随机读写

**要求:**

1. 请描述文件的复制实现过程

答：同时打开两个文件test1、test2，将test1文件中的内容读到test2
	文件中，然后将test1、test2文件关闭，即完成了文件之间的复制。

2. 如何理解文件的定位？

答：在读取文件的时候需要知道文件当前的位置，这时候需要定位。

3. 如何获取当前的读写位置呢？

答：使用tell()来获取当前文件的读写位置。

4. 如果在读写文件的过程中，需要从另外一个位置进行操作的话，该怎么操作？

答：使用seek()。

5. seek()函数有几个参数，分别代表什么？

答：seek(offset, from)有2个参数
		offset:偏移量
		from:方向

6. seek(5,0)表示什么意思？

答：5：表示偏移量为5,0：表示文件的开头

7. seek(-5,2)表示什么含义？

答：表示从文件末尾向前偏移5个字符

8. seek(3,1)表示什么含义？

答：表示从文件当前位置向后偏移3个字符。
**提示:**

1. 文件的复制过程实质上就是把一个文件中的内容读出来，然后写入另一个文件中。
2. 获取文件当前位置用tell(),重新设置读写位置要用seek().
3. 在 python3 里不允许使用负数作为偏移量，并且只有相对于头部才允许使用0以外的数字


## 练习题2

文件的相关操作、练习及应用

编写一段代码完成以下要求

**要求：**
1. 使用os模块创建一个名为“盖伦”的文件夹

2. 获取盖伦文件夹当前所在目录

3. 获取当前路径的文件列表

4. 切换工作路径为桌面

5. 将盖伦文件夹删除


import os
os.mkdir("盖伦")

os.getcwd()

os.listdir("./")

os.chdir("../")

os.rmdir("盖伦")

# Python基础语法--面向对象1(关卡一)

## 练习题1

概念理解

**要求:**

1. 如何理解面向对象编程(OOP),它和面向过程编程的区别是什么
    * 面向过程编程，代码的每一步都需要程序员自己处理
    * 面向对象编程，隐藏了代码细节，程序员只要找到别人写好的类调用即可
2. 什么是类，什么是对象
    * 类描述了一种事物的全部特征和行为
    * 对象是基于类存在的一个具体个体
**提示：**

1. 类和对象：类是对一类具体的事物的抽象的概括，具有相似内部状态和运动规律的实体的集合，具有相同属性和行为事物的统称，是抽象的；对象是一个具体的事物，在现实世界中可以是看得见摸得着的，可以直接使用的
2. 拥有相同(或者类似)属性和行为的对象都可以抽像出一个类


## 练习题2

定义类、创建对象

**要求:**

1. python中定义一个类的语法格式是什么

    ```python
    class 类名:
        代码
    ```

2. 类(class)由哪三个部分构成
    * 类名
    * 属性
    * 方法

3. 类名的命名规则是什么
    * 符合标识符命名规则
    * 一般使用大驼峰命名法

4. python中如何通过类创建对象，请用代码进行说明
    * 对象名 = 类名()

5. 如何在类中定义一个方法，请用代码进行说明

    ```python
    class Person:
        def eat(self):
            print('吃东西')
    ```

6. 定义一个People类，使用People类，创建一个mayun对象，添加company属性，值是"阿里巴巴"；创建一个wangjianlin对象，添加company属性，值是"万达集团"; 打印两个对象的 company 值。(注意：不要使用 init 方法)

    ```python
    # 定义类
    class People:
        pass

    # 创建对象
    mayun = People()
    mayun.company = '阿里巴巴'

    wangjianlin = People()
    wangjianlin.company = '万达集团'

    print(mayun.company)
    print(wangjianlin.company)
    ```

7. 定义一个水果类，然后通过水果类，创建苹果对象、橘子对象、西瓜对象并分别添加上颜色属性；打印所有对象的颜色值。(注意：不要使用 init 方法)

    ```python
    # 定义类
    class Fruit:
        pass

    # 创建对象
    apple = Fruit()
    apple.color = '红色'

    orange = Fruit()
    orange.color = '黄色'

    xigua = Fruit()    
    xigua.color = '绿色'

    print(apple.color)
    print(orange.color)
    print(xigua.color)
    ```
8. 定义一个汽车类，并在类中定义一个move方法打印'汽车在移动'，然后分别创建BMW_X9、AUDI_A9对象，并添加颜色、型号等属性，然后打印出属性值, 最后调用move方法。(注意：不要使用 init 方法)

    ```python
    class Car:

        def move(self):
            print('汽车在移动')

    BMW_X9 = Car()
    BMW_X9.color = '白色'
    BMW_X9.model = 'X9'

    AUDI_A9 = Car()
    AUDI.A9.color = '黑色'
    AUDI_A9.model = 'A9'

    print(BMW_X9.color)
    print(BMW_X9.model)
    BMW_X9.move()

    print(AUDI_A9.color)
    print(AUDI_A9.model)
    AUDI_A9.move()
    ```
**提示：**

1. 可以在通过类创建出对象后，再为对象添加属性:对象名.属性名 = 值 的方式添加
2. 调用对象的方法和调用普通函数的一样，使用()来实现调用，只不过调用方法需要使用：对象名.方法名()来进行调用
