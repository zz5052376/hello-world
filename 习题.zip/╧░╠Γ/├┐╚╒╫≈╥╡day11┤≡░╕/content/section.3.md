## 练习题1：设计模式
1. 使用单例模式编写代码。
```
要求：
1.创建一个 ATM 类，具备存取款功能，能记录当前剩余的现金量。
2.创建一个 ATM 对象，初始化现金量为100 0000。取款 10000，减少剩余现金
3.再创建一个 ATM 对象，取款 10000，减少剩余现金
4.再创建一个 ATM 对象，存款 20000，增加剩余现金
```
代码：
```python
# 1.创建一个 ATM 类，具备存取款功能，能记录当前剩余的现金量。
class ATM(object):

    instance = None
    is_first_run = True

    def __new__(cls, *args, **kwargs):
        """在__new__ 方法控制这个类只生成一个对象"""
        if cls.instance == None:
            cls.instance = object.__new__(cls)

        return cls.instance

    def __init__(self, money=0):
        """在 __init__ 初始化对象属性"""
        if ATM.is_first_run:
            self.__money = money
            ATM.is_first_run = False

    def add_money(self, money):
        """存入现金"""
        self.__money += money

    def minus_money(self, money):
        """取出现金"""
        if self.__money >= money:
            # 有足够的余额才让取钱
            self.__money -= money
        else:
            print('余额不足')

    def __str__(self):
        """获取当前剩余现金量"""
        return '当前剩余的现金为：%d' % self.__money

# 2.创建一个 ATM 对象，初始化现金量为100 0000。取款 10000，减少剩余现金
atm = ATM(1000000)
atm.minus_money(10000)
print(atm)

#3.再创建一个 ATM 对象，取款 10000，减少剩余现金
atm2 = ATM()
atm2.minus_money(10000)
print(atm2)

#4.再创建一个 ATM 对象，存款 20000，增加剩余现金
atm3 = ATM()
atm3.add_money(20000)
print(atm3)
```

**提示: **
1. 单例模式的类只能创建出一个对象，不管有多少个引用，修改了一个引用的数据，其他引用的值都会发生变化

## 练习题2：异常
1. 编写代码，在异常处理中抛出异常，并解释代码执行流程。

    ```python
    try:
        print(a)
    except Exception as exp:
        print('发生了异常并记录信息:%s' % exp)
        raise exp # 抛出异常对象
    ```
    * 当执行到 print(a) 会因为不存在变量 a 产生异常，代码进入 except 执行
    * except 里打印错误信息，并将异常再次抛出
    * 再次抛出的异常无人捕捉，会传递到解释器，导致程序崩溃退出
    * 在异常里抛出异常，一般用于程序崩溃前的错误信息收集
