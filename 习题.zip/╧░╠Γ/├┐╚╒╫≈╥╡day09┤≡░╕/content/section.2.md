# Python基础语法--面向对象1(关卡二)

## 练习题1

判断以下说法是否正确，并说明理由

**要求:**



5. `__init__`方法在创建对象时，可以完成一些初始化的操作，完成一些默认的设定
    * 正确

6. `__str__`方法可以没有返回值
    * 错误，`__str__` 方法必须要有返回值，并且返回值必须是字符串类型

7. `__str__`方法可以返回除字符串以外的其他类型的数据
    * 错误，`__str__` 方法的返回值必须是字符串类型


## 练习题2

面向对象应用1

**要求:**

1. 使用 `__init__`方法，重新实现关卡一练习2里的6、7、8题，
以达到在创建对象的同时，就为对象添加对应的属性的目的

    ```python
    # 习题 6
    # 定义类
    class People:
        def __init__(self, company):
            self.company = company

    # 创建对象
    mayun = People('阿里巴巴')

    wangjianlin = People('万达集团')

    print(mayun.company)
    print(wangjianlin.company)

    # 习题 7
    # 定义类
    class Fruit:

        def __init__(self, color):
            self.color = color

    # 创建对象
    apple = Fruit('红色')

    orange = Fruit('黄色')

    xigua = Fruit('绿色')

    print(apple.color)
    print(orange.color)
    print(xigua.color)

    # 习题 8
    class Car:

        def __init__(self, color, model):
            self.color = color
            self.model = model

        def move(self):
            print('汽车在移动')

    BMW_X9 = Car('白色','X9')
    AUDI_A9 = Car('黑色', 'A9')

    print(BMW_X9.color)
    print(BMW_X9.model)
    BMW_X9.move()

    print(AUDI_A9.color)
    print(AUDI_A9.model)
    AUDI_A9.move()
    ```

2. 为前一题的代码添加 `__str__`方法，以实现当直接打印对象时，能打印出可读性较高的信息

    ```python
    # 习题 6
    # 定义类
    class People:
        def __init__(self, company):
            self.company = company

        def __str__(self):
            return '我所在的公司是 %s' % self.company

    # 创建对象
    mayun = People('阿里巴巴')

    wangjianlin = People('万达集团')

    print(mayun)
    print(wangjianlin)

    # 习题 7
    # 定义类
    class Fruit:

        def __init__(self, color):
            self.color = color

        def __str__(self):
            return '我的颜色是 %s' % self.color

    # 创建对象
    apple = Fruit('红色')

    orange = Fruit('黄色')

    xigua = Fruit('绿色')

    print(apple)
    print(orange)
    print(xigua)

    # 习题 8
    class Car:

        def __init__(self, color, model):
            self.color = color
            self.model = model

        def move(self):
            print('汽车在移动')

        def __str__(self):
            return '我的颜色是 %s，型号是 %s' % (self.color, self.model)

    BMW_X9 = Car('白色','X9')
    AUDI_A9 = Car('黑色', 'A9')

    print(BMW_X9)
    BMW_X9.move()

    print(AUDI_A9)
    AUDI_A9.move()
    ```

3. 实例辨析

    ```python
    class Test:
        def __init__(self):
            self.a = "abcdef"
        def test1(self, args1):
            print("test1----", args1)
            print("test1----", self.a)
        def test2(abc, args2):
            print("test2---", args2)
        def test3(self, args3=300)
            print("test3---", args3)

    t = Test()   # 创建对象

    以上是程序的完整代码，判断以下方法的调用哪些会报错(多选)，并写出理由
    A.  t.test1("args1") --- 正确
    B.  t.test1(args1) --- 错误，这里传递的是一个变量 args1 的值，但是程序没有定义叫 args1 的变量
    C.  t.test2(666) --- 正确
    D.  t.test2("abc", 666) --- 错误，test2 的第一个形参虽然叫 abc，但是接收的值是解释器自动传递的对象，和 self 是一样的作用，也就是 test2 能传递的实参只有 1 个，此处传递了 2个实参
    E.  t.test3(900) --- 正确
    F.  t.test3() --- 正确，缺省参数可以不传值

    问：如果要在test2方法中，打印出在init方法中定义的a属性，应怎么写
    答案: `abc.a`
    ```

**提示：**

1. 注意 `__init__`和`__str__`等方法必须有第一个形参，往往写成self，代表对象自己

## 练习题3

面向对象应用2

**要求:**

1. 任意定义一个动物类

    ```python
    class Animal:
        pass
    ```

2. 使用`__init__`方法，在创建某个动物对象时接收参数，为其添加name、age、color,food等属性，如“熊猫”，5, “黑白”，“竹子”

    ```python
    class Animal:
        def __init__(self, name, age, color, food):
            self.name = name
            self.age = age
            self.color = color
            self.food = food
    ```

3. 为动物类定义一个run方法，调用run方法时打印相关信息，如打印出“熊猫正在奔跑”

    ```python
    # 在上一题的 Animal 类里添加方法
    def run(self):
        print('%s 正在奔跑' % self.name)
    ```

4. 为动物类定义一个get_age方法，调用get_age方法时打印相关信息，如打印出“这只熊猫今年5岁了”

    ```python
    # 在上一题的 Animal 类里添加方法
    def get_age(self):
        print('这只 %s 今年 %d 岁了' % (self.name, self.age))
    ```

5. 为动物类定义一个eat方法，调用eat方法时打印相关信息，如打印出“熊猫正在吃竹子”

    ```python
    # 在上一题的 Animal 里添加方法
    def eat(self):
        print('%s 正在吃 %s' % (self.name, self.food))
    ```

6. 通过动物类分别创建出3只不同种类的动物，分别调用它们的方法，让他们跑起来，吃起来

    ```python
    # 在上一题的 Animal 类之后添加代码
    panda = Animal('熊猫',5,'黑白','竹子')
    panda.run()
    panda.get_age()
    panda.eat()

    swan = Animal('天鹅', 2, '白', '鱼')
    swan.run()
    swan.get_age()
    swan.eat()

    rabbit = Animal('兔子', 3, '白', '青草')
    rabbit.run()
    rabbit.get_age()
    rabbit.eat()
    ```

**提示：**

1. 定义方法中，必须设置一个形参叫self，这个参数不需要开发者传递，而是由python解释器在调用时，自动传递


## 练习题4

面向对象应用3

**要求:**

1. 完成课件上的烤地瓜应用

答案:参考课堂代码
