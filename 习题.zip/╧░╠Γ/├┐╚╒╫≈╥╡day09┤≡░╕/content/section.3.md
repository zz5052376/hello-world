# Python基础语法--面向对象1(关卡三)

## 练习题1

扩展应用

**要求:**

1. 思考，将身边的一个事物抽象出一个类。比如老师、学生、桌子、椅子、苹果、香蕉、枕头、被子或任意物品
2. 提供基本属性、基本的方法
3. 通过类创建出几个不同的对象
4. 打印它们的属性、调用它们的方法

    ```python
    # 这题的自由度很大，可以任意发挥，下面是一个可用的示例
    # 抽取一个教师类，提供姓名、年龄属性，说话和大哭方法
    class Teacher:

        def __init__(self, name, age):
            self.name = name
            self.age = age

        def talk(self):
            print('%s 说：你们是女生最少的一个班')

        def cry(self):
            print('%s 说: 我都 %d 岁了，连一个亿都没挣到')

    xhy = Teacher('夏侯渊', 18)
    print('%s 的年龄是 %d' % (xhy.name, xhy.age))
    xhy.talk()
    xhy.cry()

    dg = Teacher('东哥', 60)
    print('%s 的年龄是 %d' % (dg.name, dg.age))
    dg.talk()
    dg.cry()
    ```

**提示：**

1. 提取一类具体的对象的相同(或者类似)属性和行为然后成为一个类


## 练习题2

烤地瓜应用智能版

**要求:**

1. 完善烤地瓜应用
2. 先实现以下方法：
    * cook() : 把地瓜烤一段时间
    * addCondiments() : 给地瓜添加配料
    * `__init__()` : 设置默认的属性
    * `__str__()` : 让print的结果看起来更好看一些
3. 然后实现以下方法：
    * `auto_addCondiments()`: 自动随机添加一种配料
    * `auto_cook()`: 自动烤地瓜，当地瓜烤熟了，自动停止

    ```python
    # 烤地瓜的基本代码不再重复，此处只提供 auto_cook 和 auto_addCondiments 方法的代码

    def auto_addCondiments(self):
        """随机获取一个酱料添加到地瓜上"""
        # 准备好可以使用的酱料
        datas= ["番茄酱","沙拉酱","芥末酱","辣椒酱"]  

        # 在佐料列表的下标范围类生成一个数字
        index = random.randint(0, len(datas)-1)  

        # 将随机获取的佐料添加到地瓜的属性里
        self.condiments.append(datas[index])  

    def auto_cook():
        """自动生成要烤的时间并烤一次地瓜，发现已经烤熟则停止"""
        while True:
            # 随机生成一个要烤的时长
            time = random.randint(0, 10)

            # 烤一次地瓜
            self.cook(time)

            # 判断地瓜是否已经烤熟，已经烤熟则停止烤地瓜
            if self.cooked_level >= 8:
                break
    ```

**提示：**

1. `auto_cook`方法使用循环，调用cook方法，每次循环都判断一次地瓜的状态，一旦地瓜烤熟了，就立刻使用break终止循环
2. `auto_addCondiments`方法: 可以先在`__init__`方法中，为地瓜设计一个condiments属性，类型为列表，数据如["番茄酱","沙拉酱","芥末酱","辣椒酱"]等等，然后在调用cook方法时，随机选择一种，作为配料来添加



## 练习题3

复习回顾

**要求:**

1. 回顾今天写的代码，如果没有写注释，那么为自己的代码写上相关注释，提高代码可读性

2. 理清今天代码的每一行的效果和含义
