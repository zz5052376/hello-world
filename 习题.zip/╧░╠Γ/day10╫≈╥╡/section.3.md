# Python基础语法--面向对象2(关卡三)

## 练习题1

编写一段代码以完成下面的要求

**要求：**

1. 定义一个人的基类,类中要有初始化方法,方法中初始化人的姓名,年龄.

2. 提供__str__方法，返回姓名和年龄信息

2. 将类中的姓名和年龄私有化.

3. 提供获取私有属性的方法.

4. 提供可以设置私有属性的方法.

5. 设置年龄时限制范围(0-100).

class Person(object):
    
    def __init__(self,name,age):
        self.__name = name
        self.__age = age
    
    def __str__(self):
        return "名字是%s,年龄是%d"%(self.__name,self.__age)
    
    def get_age(self):
        return self.__age
    
    def get_name(self):
        return  self.__name
    
    def set_age(self,age):
        if 0 <= age <= 100:
            self.__age = age
        else:
            print("年龄应该在0-100岁之间")
    
    def set_name(self,name):
        self.__name = name

**提示：**

1. 将公有属性变为私有属性的方法是在其前面加上__即可.

	
## 练习题2

编写一段代码以练习继承和多态

**要求：**

1. 创建一个动物的基类,其中有一个run方法

2. 创建一个Cat类继承于动物类

3. 创建一个Dog类继承于动物类

4. Cat类中不仅有run方法还有eat方法

5. Dog类中方法同上

6. 创建一个letRun函数，可以接收动物及其子类对象，并调用run方法

6. 编写测试代码以验证功能正常

class Animal(object):
    def run(self):
        print("跑起来了")


class Cat(Animal):
    def run(self):
        print("小猫跑起来了")

    def eat(self):
        print("小猫爱吃鱼")


class Dog(Animal):
    def run(self):
        print("小狗跑起来了")

    def eat(self):
        print("小狗爱吃肉")


def letRat(animal):
    # Animal.run(animal)
    animal.run()

animal = Animal()
dog = Dog()
cat = Cat()
letRat(dog)
print()
letRat(cat)
print()
letRat(animal)


## 练习题3

标出下列代码中哪些是is-a的关系，哪些是has-a的关系。有##的地方是需要标注的地方.

**要求：**
```Python
class Animal(object):  
    pass  
  
## 1
class Dog(Animal):                   #Dog is a Animal
  
    def __init__(self, name):  
        ## 2                         #Dog has a name
        self.name = name  
  
## 3 
class Cat(Animal):                   #Cat is a Animal
  
    def __init__(self, name):  
        ## 4  
        self.name = name             #Cat has a name
  
## 5  
class Person(object):                #Person is a object
  
    def __init__(self, name):  
        ## 6                         #Person has a name
        self.name = name              Persin has a pet
        self.pet = None  
  
## 7  
class Employee(Person):              #Employee is a Person
  
    def __init__(self, name, salary):  
        
        super(Employee, self).__init__(name)  
        ## 8                                      #Employee has a salary
        self.salary = salary  
  
## 9  
class Fish(object):                 #Fish is a object
    pass  
  
## 10                               #Salmon is a Fish
class Salmon(Fish):  
    pass  
  
## 11                               #Halibut is a Fish
class Halibut(Fish):  
    pass  
  
  
## 12
rover = Dog("Rover")                #rover is a Dog
  
## 13 
satan = Cat("Satan")                #satan is a Cat
  
## 14 
mary = Person("Mary")               #mary is a Person
```

**提示：**

1. is-a就是对象和类之间通过类的关系相关联
2. has-a是对象和类相关联是因为他们彼此引用
