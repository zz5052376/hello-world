# 字符串、列表、元组、字典（关卡三）

### 练习题1

字符串、列表、字典综合应用

**要求：**
 1. 用户注册登录系统V2.0
    * 设计一个程序
    * 要求用户可以实现登录、注册、注销登录等功能
    * 用户的用户名(长度6-20)、密码(长度8-20)、昵称、年龄信息保存到字典中
    * 将每个已注册用户的保存到列表中，即将上一步的字典保存到列表中
    * 维护用户的登录状态，每次只能有一个用户处于登录状态，直到选择注销登录
    * 如果不选择退出系统，该程序应当一直运行
 
```python
# 准备空列表
users = []

# 准备当前在线用户
online_user = {}

while True:
    # 打印系统提示
    print("欢迎使用 用户注册登录系统V2.0")
    print("1.登录")
    print("2.注册")
    print("3.注销登录")

    # 获取用户操作
    command = input("请输入要操作的数字:")

    # 判断用户操作
    if command == '1':
        # 登录
        if len(online_user) != 0:  # 在线用户的字典里有数据，说明已经有用户登录 
            print("已经登录了一个帐号 %s，请先注销！" % online_user['acc'])
            continue

        # 获取帐号、密码
        acc = input("请输入帐号：")
        pwd = input("请输入密码：")

        # 判断是否存在匹配的帐号密码
        for user in users:
            if user['acc'] == acc and user['pwd'] == pwd:
                print("登录成功")
                online_user = user
                break
        else:
            print("登录失败，帐号或密码错误！")

    elif command == '2':
        # 注册
        # 获取用户信息
        # 帐号
        while True:
            acc = input("请输入账号:")
            if len(acc) < 6 or len (acc) > 20:
                print("帐号长度需要在 6-20 个字符")
                continue
            else:
                break

        # 密码
        while True:
            pwd = input("请输入密码:")
            if len(pwd) < 8 or len (pwd) > 20:
                print("密码长度需要在 8-20 个字符")
                continue
            else:
                break

        # 昵称
        nick = input("请输入昵称：")

        # 年龄
        age = input("请输入年龄：")

        # 保存信息到字典
        info = {}
        info['acc'] = acc
        info['pwd'] = pwd
        info['nick'] = nick
        info['age'] = age

        # 保存字典到用户列表
        users.append(info)

    elif command == '3':
        # 注销登录
        if len(online_user) != 0:
            online_user = {}
            print("注销成功！")
        else:
            print("您还没有登录！")
```

**提示：**
 1. 题1：
    * 维护用户登录：用一个变量如 loginUser去记录一个已登录用户的用户名，如果注销登录或者未登录状态，那么就把loginUser的值设为""(空字符串)，每次判断loginUser就能得知当前是否有用户已经登录


### 练习题2

字符串、列表、字典综合应用

1. 判断有效日期
    * 用户可以输入"20170327"等三种格式的日期
    * 判断是否是有效日期，如"20170229"不是有效日期，"20171345"不是有效日期

```python
# 保存有 31 号的月份
month_has_day31 = [1, 3, 5, 7, 8, 10, 12]
# 保存有 30 号的月份
month_has_day30 = [4, 6, 9, 11]

while True:
    # 获取输入
    date = input("请输入一个有效的日期(格式为 yyyymmdd):")

    # 如果有非数字的字符将导致无法比较，需要先进行内容验证
    if not date.isdigit(): # isdigit 是字符串类型提供的操作，可以判断字符串内容是否都是数字
        print("输入的内容必须都是数字！！")
        continue

    # 获取月份并判断
    month = int(date[4:6])
    if month < 1 or month > 12:
        print("无效的日期，月份必须在 1-12 范围内")
        continue

    # 获取天数并判断
    day = int(date[6:])
    if day < 1:
        print("无效的日期，天数不能小于 1")

    elif month == 2 and day > 28:
        print("无效的日期，2月的天数不能大于 28")

    elif (month in month_has_day31) and day > 31:
        print("这个月的天数不能大于 31")

    elif (month in month_has_day30) and day > 30:
        print("这个月的天数不能大于 30")

    else:
        print("这个天数是正确的")
```

**提示：**
 
 1. 使用切片得到年、月、日，并转换年、月、日为数字
 2. 判断年份是否有效。实际上，年份是没有限制的。但是需要区分是否为闰年，供后面判断使用。创建一个变量如isRunNian=False，如果是闰年isRunNian=True
 3. 判断月份是否有效，判断输入的月份是否在[1,2,3,4,5,6,7,8,9,10,11,12]中
 4. 判断天数是否有效，非闰年各个月份的天数为[0,31,28,31,30,31,30,31,31,30,31,30,31],闰年则为[0,31,29,31,30,31,30,31,31,30,31,30,31]。列表的下标就代表月，比如索引1，就是1月份，其最大日期号是31。如果输入的日期在对应月份的最大天数范围内，才能确定是有效日期



