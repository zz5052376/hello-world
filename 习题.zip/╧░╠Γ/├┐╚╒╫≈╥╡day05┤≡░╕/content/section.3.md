# 函数(关卡三)

### 练习题1

字符串、列表、字典综合应用

**要求：**
 1. 用户注册登录系统V2.0
    * 设计一个程序
    * 要求用户可以实现登录、注册、注销登录等功能
    * 用户的用户名(长度6-20)、密码(长度8-20)、昵称、年龄信息保存到字典中
    * 将每个已注册用户的保存到列表中，即将上一步的字典保存到列表中
    * 维护用户的登录状态，每次只能有一个用户处于登录状态，直到选择注销登录
    * 如果不选择退出系统，该程序应当一直运行
 
 # 准备空列表
users = []

# 准备当前在线用户
online_user = {}

while True:
    # 打印系统提示
    print("欢迎使用 用户注册登录系统V2.0")
    print("1.登录")
    print("2.注册")
    print("3.注销登录")

    # 获取用户操作
    command = input("请输入要操作的数字:")

    # 判断用户操作
    if command == '1':
        # 登录
        if len(online_user) != 0:  # 在线用户的字典里有数据，说明已经有用户登录 
            print("已经登录了一个帐号 %s，请先注销！" % online_user['acc'])
            continue

        # 获取帐号、密码
        acc = input("请输入帐号：")
        pwd = input("请输入密码：")

        # 判断是否存在匹配的帐号密码
        for user in users:
            if user['acc'] == acc and user['pwd'] == pwd:
                print("登录成功")
                online_user = user
                break
        else:
            print("登录失败，帐号或密码错误！")

    elif command == '2':
        # 注册
        # 获取用户信息
        # 帐号
        while True:
            acc = input("请输入账号:")
            if len(acc) < 6 or len (acc) > 20:
                print("帐号长度需要在 6-20 个字符")
                continue
            else:
                break

        # 密码
        while True:
            pwd = input("请输入密码:")
            if len(pwd) < 8 or len (pwd) > 20:
                print("密码长度需要在 8-20 个字符")
                continue
            else:
                break

        # 昵称
        nick = input("请输入昵称：")

        # 年龄
        age = input("请输入年龄：")

        # 保存信息到字典
        info = {}
        info['acc'] = acc
        info['pwd'] = pwd
        info['nick'] = nick
        info['age'] = age

        # 保存字典到用户列表
        users.append(info)

    elif command == '3':
        # 注销登录
        if len(online_user) != 0:
            online_user = {}
            print("注销成功！")
        else:
            print("您还没有登录！")

**提示：**
 1. 题1：
    * 维护用户登录：用一个变量如 loginUser去记录一个已登录用户的用户名，如果注销登录或者未登录状态，那么就把loginUser的值设为""(空字符串)，每次判断loginUser就能得知当前是否有用户已经登录


### 练习题2

嵌套列表应用

 1. 有10个球分别3红、3蓝、4白，现需要将这10个球放入这3个盒子，要求每个盒子至少有一个白球，请用程序实现

import random
# 定义一个列表用来保存3个盒子
boxs = [[],[],[]]
# 定义一个列表用来存放10个球
balls = ['w','w','w','w','r','r','r','b','b','b']

# 判断条件,把球添加到盒子里面
i = 0
for ball in balls:
    if ball == "w" and i < 3:
        if i == 0:
            boxs[0].append(ball)
        if i == 1:
            boxs[1].append(ball)
        if i == 2:
            boxs[2].append(ball)
        i += 1
    else:
        index = random.randint(0,2)
        boxs[index].append(ball)
print(boxs)


**提示：**
 1. 题1:
    * 使用嵌套列表模拟三个盒子
    * 先向每个盒子放入一个白球，然后再遍历剩余的球随机放入一个盒子里

### 练习题2

将第4天的关卡三的题封装为函数并调用

**要求：**
1. 用户注册登录系统V2.0
    * 至少封装出3个函数(注册，登陆，注销)

    # 判断是否是管理员身份
def is_admin(user):
    if user:
        if user["username"] == "admin":
            return True
    return False

# 注册用户
def register(user_list):
    name = input("请输入昵称：")    # 昵称
    username = input("请输入用户名(登录用):")    # 用户名，应判断是否存在
    for user in user_list:
        # 判断用户名是否已经存在
        if user["name"] == username:
            print("用户名%s已经存在，请重试")
            return False    # 如果存在，则重新输入
    passwd1 = input("请输入密码：")
    passwd2 = input("请确认密码：")
    # 判断两次密码是否一致
    if passwd1 != passwd2:
        print("密码不一致，请重新输入")
        return False    # 不一致则重新输入
    # 否则，注册成功
    newuser={"name":name, "username": username, "passwd":passwd1}
    # 添加到用户列表
    user_list.append(newuser)
    return True

# 查看注册用户列表
def view_users(loginUser,user_list):
    # 判断是否已经登录
    if loginUser:
        # 判断当前用户是不是管理员
        if not is_admin(loginUser):
            print("权限不足，请获取管理员权限")
            return
        else:
            i = 1
            for u in user_list:
                print("No%d. "%i, u)
                i += 1
    else:
        print("请以管理员身份登录并查看")

# 打印菜单
def menu(user):
    print("      python攻城狮系统V6.0")
    if not user:
        print("1.登录")    
    else:
        print("1.登出")
    print("2.注册新用户")
    print("3.查看所有已注册用户")
    print("4.管理员身份")
    print("5.查看当前登录用户")
    print("6.退出系统")

# 主函数
def main():
    loginUser = False
    user_list = [{"name":"系统管理员", "username":"admin", "passwd": "123456"}]
    while True:
        menu(loginUser)
        cmd = input("命令：")
        # 登录登出管理
        if cmd == "1":
            # 如果是以登录状态，则询问是否注销登录
            if loginUser:
                yn = input("确认注销登录(y/n)")
                if yn == "y":
                    print("%s注销登录成功"%loginUser["name"])
                    loginUser = False
                    continue
            # 如果是为登录状态，则进行登录
            else:
                username = input("请输入用户名：")
                passwd = input("请输入密码：")
                login = None    # 判断输入的用户是否存在
                for user in user_list:
                    # 判断输入的用户是否存在，以及密码是否正确
                    if user["username"]==username and user["passwd"]==passwd:
                        login = user
                # 如果存在，且密码校验成功，则提示登录成功，并赋值非loginUser
                # 否则提示"用户名密码错误或用户名不存在"
                if login:
                    print("欢迎%s，登录成功"%login["name"])
                    loginUser = login
                else:
                    print("用户名密码错误或用户名不存在")
        # 注册新用户，添加新用户
        elif cmd == "2":
            while True:
                temp = register(user_list)
                if temp:
                    print("注册成功")
                    break
                else:
                    continue
        # 查看所以已注册用户的信息，应具备管理员权限
        elif cmd == "3":
            view_users(loginUser,user_list)
        # 管理管理员账户
        elif cmd == "4":
            # 要求先登录
            if not loginUser:
                print("请先登录")
                continue
            else:
                # 如果不是管理员
                if loginUser["username"] != "admin":
                    print("权限不足，请获取管理员权限")
                    continue
            for u in user_list:
                if u["username"] == "admin" and loginUser["username"] == "admin":
                    yn = input("需要修改管理员密码吗？(y/n)")
                    if yn == "y":
                        oldpasswd = input("请输入原密码：")
                        if oldpasswd == loginUser["passwd"]:
                            newpasswd = input("请输入新密码：")
                            loginUser["passwd"] = newpasswd
                            print("管理员密码已更新")
                        else:
                            print("密码错误，请重新输入")
                            continue
        # 查看当期那登录用户是谁
        elif cmd == "5":
            if loginUser:
                print("当前登录的用户为%s(%s)"%(loginUser["name"], loginUser["username"]))
            else:
                print("当前登录的用户为匿名用户")
        # 退出
        elif cmd  == "6":
            print("退出成功，谢谢您的使用！")
            break

main()
    
2. 判断有效日期
    * 至少封装出4个函数(年月日转换，闰年判断，月份判断，日期判断)

# 判断用户输入是否合法
def is_legal_input(date):
    # 如果长度不为8或者不是纯数字，则重新输入
    if len(date) != 8 or not date.isdigit():
        return False
    else:
        return True

# 判断是否是闰年
def is_leapyear(year):
    if (year%4==0 and year%100!=0) or year%400==0:
        return True
    else:
        return False

# 判断月数是否合法：
def is_legal_month(month):
    # 判断月分是否合法
    if month < 1 or month >12:
        return False
    else:
        return True

# 判断日期是否合法
def is_legal_day(year, month, day):
    # 下标即对应月份数
    pingnian_month = [0,31,28,31,30,31,30,31,31,30,31,30,31]
    runnian_month = [0,31,29,31,30,31,30,31,31,30,31,30,31]
    if is_leapyear(year):
        # 判断日期是否合法
        if day<1 or day>runnian_month[month]:
            return False    # 不合法直接重新输入
        else:
            return True
    else:
        # 判断日期是否合法
        if day<1 or day>pingnian_month[month]:     
            return False
        else:
            return True
# 主函数
def main():  
    while True:
        date = input("请输入一个日期(8位)：")
        # 如果输入QUIT则退出
        if date == "QUIT":
            break
        # 如果长度不为8或者不是纯数字，则重新输入
        if not is_legal_input(date):
            print("请输入一个有效的八位数日期，如20170327")
            continue
        else:
            year = int(date[0:4])    # 截取年份
            month = int(date[4:6])    # 截取月份，注int("02")--->2
            day = int(date[6:])    # 截取日期
            # 如果不合法，则重新输入
            if not is_legal_month(month):
                print("您输入的%s不是有效日期, 请重新输入"%date)
                continue
            if not is_legal_day(year, month, day):
                print("您输入的%s不是有效日期, 请重新输入"%date)
                continue
            # 如果都合法，则打印以下信息
            print("您输入的%s是有效日期"%date)
            print("="*30)

main()

### 练习题3

1. 使用函数求前n个数的斐波那契数列。n为函数参数

def feibo(n):
 a = 1
 b = 1
 i = 1
 while i <= n:
     if i ==1 or i ==2:
         print(1)
     else:
         a, b = b, a + b
         print(b)
     i += 1

n = input("请输入所求数字:")
feibo(n)

提示：
 1.斐波那契数列：1,1,2,3,5,8,13,21...即: 起始两项均为1，此后的项分别为前两项之和。
 2.也就是说n=1则返回1，n=2则返回1，n=3则返回2，n=4则返回3，以此类推
