# 函数(关卡二)
### 练习题1

字典的基本应用

**要求：**
 
 1. 字符翻译程序
    * 查看笔记本键盘1-9还有0号键其上方的字符，要求用户输入"1"，那么输出"!",输入"2"，那么输出"@",以此类推
    * 用字典完成这个任务
    * 用户如果输入的字符长度超过1或者是除数字以外其他字符，提示"未收录该字符的含义，请重新输入"
 
# 1~9 按键的翻译
# 用户输入指令:
while True:
    dict1 = {"1":"!","2":"@","3":"#","4":"$","5":"%","6":"^","7":"&","8":"*","9":"(","0":")"}
    a = input("请输入操作指令:")
    if a not in dict1.keys():
        print("请重新输入:")
        continue
    print(dict1[a])
 2. 职员信息管理系统
    * 使用列表来记录多个员工的信息
    * 要求依次从键盘录入每位员工的信息，并使用字典来保存，包括姓名、员工id、出生年月、籍贯、身份证号、入职时间
    * 要求能随时查看已录入的员工及其信息

 答案: 参考课堂的 名片管理系统-字典版

**提示：**
 
 1. 题1：
    * 使用字典来存储，键为出现过的字符，值为字符出现的次数，比如 {'a':2,'c':1}
    * 使用for循环遍历每个字符，循环里使用  if 字符 in dict 判断字典是否已经存在该字符的键，存在则把对应键的数字+1
 
 2. 题1：
    * 使用字典先设计好{"1":"!","2":@ ......}来存储
    * 然后通过用户输入的字符来获取                                                
 
 3. 题2：
    * 每位职员的信息可以用字典保存，然后添加到一个职员列表中进行管理，要查看时，遍历这个职员列表即可

### 练习题2

**要求：**

1. 写一个程序，由用户输入一个年份，调用函数判断是否是闰年。
    * 年份作为参数传递给函数
    * 函数需要有返回值

提示：
1.能被400整除的年份 
2.能被4整除，但是不能被100整除的年份
以上2种方法满足一种即为闰年

def year(y):
    if y % 400 == 0 or (y % 100 != 0 and y % 4 == 0):
        return '闰年'
    else:
        return '平年'
y = int(input('请输入年份:'))
print('%d年是%s' % (y, year(y)))

### 练习题3

将第4天的关卡二中的每一题的代码封装成函数并调用

**要求：**

1. 完成字符串的逆序以及长度统计
    * 将字符串作为函数参数传入

def str_reverse(str_input):
    while True:
        # 测试长度：
        if len(str_input)<1 or len(str_input)>31:
            print("长度超出限制，请重新输入")
            continue
        # 如果输入“QUIT”则退出程序
        if str_input == "QUIT":
            break
        # 打印其长度并逆序打印字符串
        print("您输入的字符串%s\n"%str_input,\
              "长度：%d\n"%len(str_input),\
              "逆序后为：%s"%str_input[::-1]\
              )
        return str_input[::-1]
# 获取键盘输入
str_input = input("请任意输入一个字符串(长1-31)：")
ret = str_reverse(str_input)
print(ret)

2. 用户名和密码格式校验程序:
    * 将键盘输入的数据作为函数参数传入

# 校验函数
def verify_input(username, passwd):
    # 校验用户名格式是否在6-20之间
    if len(username)<6 or len(username)>20:
        print("请输入有效的用户名，长度6-20，且必须以字母开头")
        print("请重新输入")
        # 如果不正确直接使用return，终结函数的执行
        return
    # 查看用户名是不是以字母开头
    if username[0] not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ":
        print(username[0])
        print("请输入有效的用户名，长度6-20，且必须以字母开头")
        print("请重新输入")
        # 如果不正确直接使用return，终结函数的执行
        return
    # 校验密码格式6位，不能为纯数字，不能有空格
    if len(passwd) < 6 or passwd.isdigit() or " " in passwd:
        print("密码长度至少6位，不能为纯数字，不能有空格")
        print("请重新输入")
        # 如果不正确直接使用return，终结函数的执行
        return
    # 当校验成功后才执行下面两句
    print("校验成功")
    print("="*20)

# 主函数，控制循环
def main():
    while True:
        # 获取用户输入
        username = input("请输入用户名：")
        # 获取输入的密码
        passwd = input("请输入密码：")
        # 如果输入“QUIT”则退出程序
        if username == "QUIT":
            break
        # 调用校验程序
        verify_input(username,passwd)

# 调用主函数
main()

3. 从键盘中输入5个学生的名字，存储到列表中，然后打印出每个学生名字中的第二个字母
    * 将列表作为函数参数传入

# 定义返回生成后的学生列表
def make_stu_list(num):
    i = 1
    # 存放学生的列表
    student_list = []
    # 依次添加5名学生
    while i<=5:
        student = input("请输入第%d名学生的姓名："%i)
        student_list.append(student)
        i += 1
    return student_list
# 定义打印任务的函数
def print_mess():
    student_list = make_stu_list(5)
    # 遍历学生列表
    for stu in student_list:
        print("%s的第二个字母为%s"%(stu,stu[1]))
# 调用函数打印信息
print_mess()

4. 从键盘获取5个学生的名字，然后随机抽出一名学生去打扫卫生
    * 将存储学生名字的列表作为函数参数传入

import random

# 定义返回生成后的学生列表
def make_stu_list(num):
    i = 1
    # 存放学生的列表
    student_list = []
    # 依次添加5名学生
    while i<=5:
        student = input("请输入第%d名学生的姓名："%i)
        student_list.append(student)
        i += 1
    return student_list

# 随机获得一名学生
def get_student(student_list):

    # 在0-4中随机获取一个值作为下标，获取一名学生
    random_index = random.randint(0,len(student_list)-1)
    return student_list[random_index]
# 打扫卫生
def clean_room(stu,day):
    print("day%d"%day)
    print("%s被派去打扫卫生了"%stu)

# 主函数
def main():
    student_list = make_stu_list(5)     # 定义返回生成后的学生列表
    day = 1
    cmd = "c"    # 默认为c，则第一次直接执行
    while True:
        # 如果用户出入q代表退出
        if cmd == 'q':
            print("放假了，不再需要有人打扫了")
            break
        # 如果输入c，代表继续
        elif cmd == "c":
            stu = get_student(student_list)    # 随机获得一名学生
            clean_room(stu,day)    # 打扫卫生
            day += 1    # 日期+1
        # 否则提示不能被识别
        else:
            print("未识别的命令")
        cmd = input("请输入命令：(q/退出,c/继续)")

main()

6. 名片管理器v2.0
    * 至少封装成三个函数，并且都将存放名片的列表作为参数传入
    * 一个函数负责添加名片
    * 一个函数负责打印功能
    * 一个函数负责清空功能

#添加名片
def add_cart(cart_list):
    # 获取用户输入
    name = input("请输入姓名(6-20)：")
    gender = input("请输入性别(男或女)：")
    company = input("请输入公司：")
    address = input("请输入公司地址：")
    phone = input("请输入联系方式(手机)：")
    # 检测姓名是不是在6-20之间
    if len(name)<6 and len(name)>20:
        print("姓名长度只能是6-20位")
        # 如果不符合条件，那么重新输入，所以返回False值
        return False
    # 检测电话号码是否有效的11位
    if len(phone) != 11:
        print("请输入有效的电话号码")
        # 如果不符合条件，那么重新输入，所以返回False值
        return False
    # 控制性别的输入只能是男或女
    if gender not in "男女" and len(gender) != 1:
        print("请输入有效的性别(男或女)")
        # 如果不符合条件，那么重新输入，所以返回False值
        return False
    # 所有数据不能为空，如果为空，那么重新输入
    if name=="" or gender=="" or company=="" or address=="" or phone=="":
        print("输入不能为空")
        return False
    # 创建新名片
    cart = [name,gender,company,address,phone]
    # 把名片添加到名片列表里
    cart_list.append(cart)
    print("添加成功")
    return True    # 成功就返回True值，不再继续

#删除名片
def delete_cart(cart_list):
    num = int(input("请输入要删除第几个名片"))
    # 因为下标号从0开始，所以需要-1
    cart_list.pop(num-1)
    print("删除成功")

# 查看所有名片
def view_cart(cart_list):
    i = 1
    # 遍历名片列表
    for c in cart_list:
        print("%d. "%i,c)
        i += 1   
# 主函数
def main():
    cart_list = []
    while True:
        print("      名片管理器V2.0")
        print("1.添加名片")
        print("2.删除名片")
        print("3.查看所有名片")
        print("4.退出")
    
        cmd = input("请输入命令:")
        # 添加名片
        if cmd == "1":
            ret = False # 判断是否添加成功
            while True:
                if ret:
                    break   # 如果成功则跳出该循坏
                else:
                    ret = add_cart(cart_list)   # 否则继续
        # 删除名片
        if cmd == "2":
            delete_cart(cart_list)
        # 查看名片
        if cmd == "3":
            view_cart(cart_list)
        # 退出
        if cmd == "4":
            break

main()

7. 字符翻译程序
    * 用户输入的字符作为函数参数传入

# 字符对应的字典
char_dict = {"1":"!", "2":"@","3":"#","4":"$","5":"%","6":"^","7":"&","8":"*","9":"(","0":")"}
# 主函数
def main():
    while True:
        cmd = input("请输入命令：")
        # 如果输入的是"0123456789"中的数字才执行
        if cmd in "0123456789" and len(cmd) == 1:
            print("键盘中%s号键对应的符号是%s"%(cmd,char_dict[cmd]))
        elif cmd == "quit":
            print("谢谢使用")
            break
        else:
            print("未识别的命令")

main()

8. 职员信息管理系统
    * 至少封装成两个函数
    * 一个函数负责添加职员
    * 一个函数负责查看已录入的职员及其信息

# 添加信息
def add_mess():
    # 获取用户输入
    info = {}
    name = input("请输入员工姓名：")
    id_cart = input("请输入身份证号：")
    work_id = input("请输入工作id：")
    birthday = input("请输入出生年月：")
    home_address = input("请输入籍贯：")
    first_day = input("请输入入职时间：")
    # 检测身份证号码格式是否正确，除了第18位可以为x，其余都只能为数字
    if len(id_cart) == 18 and id_cart[0:17].isdigit() and id_cart[17:] in "xX0123456789":
        # 符合要求的话，可以什么都不用做
        pass
    else:
        # 否则提示输入有误，并重新输入
        print("请输入有效的身份证号格式")
        print("请重新输入")
        return False
    # 检测工作id是不是为纯数字
    if not work_id.isdigit():
        print("工作id必须是纯数字")
        print("请重新输入")
        return False
    # 生成存储有该员工信息的字典
    info = {"name":name,"id_cart":id_cart,"work_id":work_id,"birthday":birthday,"home_address":home_address,"first_day":first_day}
    return info

# 删除信息
def delete_mess(info_list):
    name2 = input("请输入要删除的员工的名字：")
    info = ''
    for i in info_list:
        # 找到后，赋值给info
        if i["name"] == name2:
            info = i
    # 如果没找到name2员工，表明info是""，则不进行删除操作
    if info != "":
        info_list.remove(info)
        print("删除成功")
        info = ""
    else:
        print("没有员工%s的信息"%name2)
        
# 编辑信息
def edit_mess(info_list):
    name3 = input("请输入需要编辑的员工的名字：")
    info = ''
    for i in info_list:
        # 找到后，赋值给info
        if i["name"] == name3:
             info = i
    # 如果没找到name3员工，表明info是""，所以不进行编辑操作
    if info != "":
        birthday = input("请输入出生年月：")
        home_address = input("请输入籍贯：")
        first_day = input("请输入入职时间：")
        info["birthday"] = birthday
        info["home_address"] = home_address
        info["first_day"] = first_day
        print("编辑成功")
    else:
        print("没有员工%s的信息"%name3)
        
# 查看信息
def view_mess(info_list):
    i = 1
    # 遍历列表，每一个c就是每位员工的个人信息
    for c in info_list:
        print("%d. "%i,c)
        i += 1

# 打印菜单
def menu():
    print("      职员信息管理系统")
    print("1.添加新员工信息")
    print("2.删除员工信息")
    print("3.编辑员工信息")
    print("4.查看所有员工信息")
    print("5.退出")  
# 主函数
def main():
    # 存放所有员工信息的列表
    info_list = []
    while True:
        menu()
        cmd = input("请输入命令:")
        # 添加信息
        if cmd == "1":
            ret = False    # 判断是否添加成功
            while True:
                if ret:
                    info_list.append(ret)
                    print("添加成功")
                    break
                else:
                    ret = add_mess()
        # 删除信息
        if cmd == "2":
            delete_mess(info_list)
        # 编辑信息
        if cmd == "3":
            edit_mess(info_list)
        # 查看信息
        if cmd == "4":
           view_mess(info_list)
        # 退出
        if cmd == "5":
            break

main()